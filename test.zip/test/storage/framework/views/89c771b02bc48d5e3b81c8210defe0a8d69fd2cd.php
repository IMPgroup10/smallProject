<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Contacts
					<small class="float-right">
						<button class="btn-xs btn-primary" data-toggle="collapse" href="#search">Search</button>
					</small>
					<small class="float-right">
						<button class="btn-xs btn-success" data-toggle="collapse" href="#contactForm">Add</button>
					</small>
					<!-- <small class="float-right">
						<button class="btn-xs btn-danger" data-toggle="collapse" href="#destroyButtons">Remove</button>
					</small> -->

				</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
					<div class="collapse col-md-8" id="contactForm">
						<form method="post" action="<?php echo e(url('add')); ?>">
							<?php echo e(csrf_field()); ?>


							<div class="form-group form-inline">
						      <label for="firstName" class="col-sm-3">First Name</label>
						      <input type="text" class="form-control col-sm-6" id="firstName" name="firstName">
						    </div>
							<div class="form-group form-inline">
						      <label for="lastName" class="col-sm-3">Last Name</label>
						      <input type="text" class="form-control  col-sm-6" id="lastName" name="lastName">
						    </div>
							<div class="form-group form-inline">
						      <label for="phone" class="col-sm-3">Phone Number</label>
						      <input type="text" class="form-control  col-sm-6" id="phone" name="phone">
						    </div>
							<div class="form-group form-inline">
						      <label for="street" class="col-sm-3">Street</label>
						      <input type="text" class="form-control  col-sm-6" id="street" name="street">
						    </div>
							<div class="form-group form-inline">
							  <label for="city" class="col-sm-3">City</label>
							  <input type="text" class="form-control  col-sm-6" id="city" name="city">
							</div>
							<div class="form-group form-inline">
							  <label for="state" class="col-sm-3">State</label>
							  <input type="text" class="form-control  col-sm-6" id="state" name="state">
							</div>
							<div class="form-group form-inline">
							  <label for="zip" class="col-sm-3">Zip</label>
							  <input type="text" class="form-control  col-sm-6" id="zip" name="zip">
							</div>
							<div class="form-group text-center">
								<input class="btn btn-primary" align="center" type="submit" value="Submit">
							</div>
						</form>
						<br><br>
					</div>
					<div class="collapse col-sm-7" id="search">
						<form class="form-inline" method="get" action="<?php echo e(url('search')); ?>">
							<?php echo e(csrf_field()); ?>


							<div class="form-group col-sm-10">
						      <label for="search" class="col-sm-3">Search</label>
						      <input type="text" class="form-control col-sm-6" id="search" name="search">
						    </div>
							<div class="form-group text-center col-sm-2">
								<input class="btn btn-primary" align="center" type="submit" value="Submit">
							</div>
						</form>
						<br>
					</div>

					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">First</th>
								<th scope="col">Last</th>
								<th scope="col">Phone</th>
								<th scope="col">Street</th>
								<th scope="col">City</th>
								<th scope="col">State</th>
								<th scope="col">Zip</th>
								<th scope="col">User</th>
								<th scope="col">Delete</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<th scope="row"><?php echo e($loop->iteration); ?></th>
								<td><?php echo e($c->firstName); ?></td>
								<td><?php echo e($c->lastName); ?></td>
								<td><?php echo e($c->phone); ?></td>
								<td><?php echo e($c->street); ?></td>
								<td><?php echo e($c->city); ?></td>
								<td><?php echo e($c->state); ?></td>
								<td><?php echo e($c->zip); ?></td>
								<td><?php echo e($c->userID); ?></td>
								<td id="destroyButtons<?php echo e($c->id); ?>">
									<a class="btn-sm btn-danger" method="get" href="destroy/<?php echo e($c->id); ?>">X</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>